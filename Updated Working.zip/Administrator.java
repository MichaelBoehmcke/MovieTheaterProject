package TicketVendor;

public class Administrator extends Account{

	public Administrator() {
		super.role="Admin";
		super.username="AdminDefault";
		super.password="admin1";
	}
	
	public String toString() {
		return super.toString();
	}
	
}
